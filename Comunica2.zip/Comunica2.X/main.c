#include "mcc_generated_files/system/system.h"
#include "mcc_generated_files/uart/uart1.h"
#include "mcc_generated_files/timer/tmr0.h"
#include "mcc_generated_files/system/interrupt.h"
#include "mcc_generated_files/system/pins.h"

#include <stdint.h>
#include <stdbool.h>
#include <string.h>
#include <stdlib.h>
#include <stdint.h>
#include <ctype.h>    

volatile int32_t PulsosEncoder = 0; 
volatile int16_t SetPoint = 0; 
volatile int16_t PosActual = 0;
volatile int16_t Error = 0; 
volatile int16_t SalidaPID = 0; 

// =================== ENUMERACIONES ===================
typedef enum {
    STATE_IDLE,
    STATE_RECEIVING,
    STATE_READY,
    STATE_DECODE,
    STATE_EXECUTE,
    STATE_SEND
} SystemState;

typedef enum {
    CMD_NONE,
    CMD_G28,
    CMD_S,
    CMD_A,
    CMD_P,
    CMD_Ki,
    CMD_Kp,
    CMD_Kd        
} CommandID;

typedef enum {
    PID_ETAPA_0_LECTURA,
    PID_ETAPA_1_ERROR,
    PID_ETAPA_2_P,
    PID_ETAPA_3_I,
    PID_ETAPA_4_D,
    PID_ETAPA_5_SALIDA,
    PID_ETAPA_6_DUTY,
    PID_ETAPA_7_Rx1,
    PID_ETAPA_8_Rx2,
    PID_ETAPA_9_Rx3,
    PID_ETAPA_10_Rx4
} PID_Etapa_t;
// =================== ESTRUCTURAS ===================
typedef struct {
    char buffer[16];
    uint8_t index;
    bool ready;
} UART_Message;

typedef struct {
    int16_t value;
    bool valid;
} SetPoint_Command;

typedef struct {
    float Ki, Kp, Kd;
} K_PID;

K_PID Constantes;

typedef enum {
    PID_FSM_IDLE = 0,
    PID_FSM_READING
} PID_FSM_State;

typedef enum {
    PID_TARGET_NONE = 0,
    PID_TARGET_KP,
    PID_TARGET_KI,
    PID_TARGET_KD
} PID_Target;

typedef struct {
    PID_Etapa_t etapa;
    int16_t PosActual;
    int16_t Error;
    int16_t ErrorPrev;
    int32_t SumError;
    int16_t Derivada;
    float P;
    float I;
    float D;
    float Acumulado;  // parcial para ir sumando P + I + D
    bool habilitado;
} PID_Data_t;

volatile PID_Data_t PID = {
    .etapa = PID_ETAPA_0_LECTURA,
    .habilitado = false
};

typedef struct {
    PID_FSM_State state;     // Si est� activa o no
    PID_Target target;       // Qu� constante se est� ajustando
    float value;             // Acumulado
    float divisor;           // Para decimales
    bool decimalMode;        // Si ya se vio ','
    uint8_t index;           // �ndice actual (3 ? 7)
    const char *buffer;      // Apuntador al mensaje recibido
} K_PID_FSM;

K_PID_FSM KParser;

typedef struct {
    SystemState state;
    UART_Message msg;
    SetPoint_Command pos;
    CommandID cmdID;
    bool txReady;
} SystemContext;

SystemContext systemCtx = {
    .state = STATE_IDLE,
    .msg = {"", 0, false},
    .cmdID = CMD_NONE,
    .txReady = false
};

// =================== PROTOTIPOS ===================
static SetPoint_Command parseP(const char *input);
void K_PID_FSM_Process(void);
static int decodeGcode(const char *input);
void RxFSM(void);


void main(void)
{
    // Inicializaci�n del sistema
    SYSTEM_Initialize();
    
    // Registrar callback de UART1
    UART1_SetRxInterruptHandler(UART1_CustomHandler);

    // Registrar callback de TMR0 (ejemplo: enviar algo cada interrupci�n)
    TMR0_PeriodMatchCallbackRegister(TMR0_UserInterrupt);

    // Habilitar interrupciones globales
    INTCON0bits.GIEH = 1;  // Habilita interrupciones globales
    INTCON0bits.GIEL = 1;  // Habilita interrupciones perif�ricas
    
    Constantes.Ki = 1.1;
    Constantes.Kp = 1.2;
    Constantes.Kd = 1.3;
    
    // Loop principal
    while (1)
    {
        RxFSM();
        K_PID_FSM_Process();
        PID_MDF();
    }
}


// =================== DECODIFICADOR DE COMANDOS ===================
static int decodeGcode(const char *input) {
    if (strncmp(input, "S", 1) == 0) return CMD_S;
    if (strncmp(input, "A", 1) == 0) return CMD_A;
    if (strncmp(input, "P", 1) == 0) return CMD_P;
    if (strncmp(input, "Ki", 1) == 0) return CMD_Ki;
    if (strncmp(input, "Kp", 1) == 0) return CMD_Kp;
    if (strncmp(input, "Kd", 1) == 0) return CMD_Kd;
    if (strncmp(input, "G28", 3) == 0) return CMD_G28;
    return CMD_NONE;
}


static SetPoint_Command parseP(const char *input) {
    SetPoint_Command cmd = {0, false};

    // Apunta al n�mero despu�s de la 'P'
    const char *numPtr = input + 1;

    // Verifica formato: debe haber signo opcional seguido de d�gitos
    if (*numPtr == '+' || *numPtr == '-' || isdigit((unsigned char)*numPtr)) {
        int val = atoi(numPtr);
        if (val >= -14500 && val <= 14500) {
            cmd.value = (int16_t)val;
            cmd.valid = true;
        }
    }

    return cmd;
}

void K_PID_FSM_Process(void) {
    if (KParser.state == PID_FSM_IDLE) return;

    char c = KParser.buffer[KParser.index];

    if (c == ',') {
        KParser.decimalMode = true;
    }
    else if (c >= '0' && c <= '9') {
        if (!KParser.decimalMode) {
            KParser.value = KParser.value * 10.0f + (c - '0');
        } else {
            KParser.value += (float)(c - '0') / KParser.divisor;
            KParser.divisor *= 10.0f;
        }
    }

    KParser.index++;

    if (KParser.index > 7) {
        // FIN ? asignar seg�n target
        switch(KParser.target) {
            case PID_TARGET_KP: 
                Constantes.Kp = KParser.value;
                break;
            case PID_TARGET_KI: 
                Constantes.Ki = KParser.value;
                break;
            case PID_TARGET_KD: 
                Constantes.Kd = KParser.value;
                break;
            default: 
                break;
        }

        // Volver a reposo
        KParser.state = PID_FSM_IDLE;
        KParser.target = PID_TARGET_NONE;
    }
}


// =================== MAQUINA DE ESTADOS DE RECEPCI�N ===================
void RxFSM(void)
{
    if (uartRxTail == uartRxHead) return; // No hay mensajes

    char *msg = (char*)uartRxBuffer[uartRxTail];

    systemCtx.cmdID = (CommandID)decodeGcode(msg);
        
    switch (systemCtx.cmdID) {
        case CMD_P:
            systemCtx.pos = parseP(msg);
            if (systemCtx.pos.valid) {
                SetPoint = systemCtx.pos.value;
                //crea un GoTo digital.
            } else {
            
            }
            break;

        case CMD_G28:
            //GoHome();
            break;

        case CMD_S:
            // ? Activa SERIAL
            break;

        case CMD_A:
            // ? Activa VOLTAJE
            break;
            
        case CMD_Kp:
            //agregar el if de que actuliza las constantes si esta ejecutando una tarea
            if (KParser.state == PID_FSM_IDLE) {   // << protecci�n
                KParser.state = PID_FSM_READING;
                KParser.target = PID_TARGET_KP;
                KParser.value = 0.0f;
                KParser.divisor = 10.0f;
                KParser.decimalMode = false;
                KParser.index = 3;
                KParser.buffer = msg;
            }
            break;

        case CMD_Ki:
            if (KParser.state == PID_FSM_IDLE ) {   // << protecci�n
                KParser.state = PID_FSM_READING;
                KParser.target = PID_TARGET_KI;
                KParser.value = 0.0f;
                KParser.divisor = 10.0f;
                KParser.decimalMode = false;
                KParser.index = 3;
                KParser.buffer = msg;
            }
            break;

        case CMD_Kd:
            if (KParser.state == PID_FSM_IDLE) {   // << protecci�n
                KParser.state = PID_FSM_READING;
                KParser.target = PID_TARGET_KD;
                KParser.value = 0.0f;
                KParser.divisor = 10.0f;
                KParser.decimalMode = false;
                KParser.index = 3;
                KParser.buffer = msg;
            }
            break;

            
        default:

            break;
    }

    uartRxTail = (uartRxTail + 1) % UART_RX_BUFFER_SIZE;
}

void PID_MDF(void)
{
    if(!PID.habilitado)
        return;

    switch(PID.etapa)
    {
        case PID_ETAPA_0_LECTURA:
            // PosActual = (PulsosEncoder * 35)   
            PID.PosActual = PulsosEncoder * 35;
            PID.etapa = PID_ETAPA_1_ERROR;
            break;

        case PID_ETAPA_1_ERROR:
            // PosActual = (PosActual / 10)  (optimizado)
            PID.PosActual = (int16_t)( PID.PosActual / 10 )
            PID.Error = SetPoint - PID.PosActual;
            PID.etapa = PID_ETAPA_2_P;
            break;

        case PID_ETAPA_2_P:
            PID.P = Constantes.Kp * PID.Error;
            PID.Acumulado = PID.P;
            // Saturaci�n temprana
            if(PID.Acumulado > 24.0f || PID.Acumulado < -24.0f) {
                PID.etapa = PID_ETAPA_5_SALIDA; 
                break;
            }
            PID.etapa = PID_ETAPA_3_I;
            break;

        case PID_ETAPA_3_I:
            PID.SumError += PID.Error;
            PID.I = Constantes.Ki * (float)PID.SumError;
            PID.Acumulado += PID.I;
            // Saturaci�n temprana
            if(PID.Acumulado > 24.0f || PID.Acumulado < -24.0f) {
                PID.etapa = PID_ETAPA_5_SALIDA; 
                break;
            }
            PID.etapa = PID_ETAPA_4_D;
            break;

        case PID_ETAPA_4_D:
            PID.Derivada = PID.Error - PID.ErrorPrev;
            PID.ErrorPrev = PID.Error;
            PID.D = Constantes.Kd * (float)PID.Derivada;
            PID.Acumulado += PID.D;
            PID.etapa = PID_ETAPA_5_SALIDA;
            break;

        case PID_ETAPA_5_SALIDA:
            // Saturaci�n final
            if(PID.Acumulado >  24.0f) PID.Acumulado =  24.0f;
            if(PID.Acumulado < -24.0f) PID.Acumulado = -24.0f;

            PID.Acumulado = PID.Acumulado / 6;

            // Terminar el ciclo
            PID.etapa = PID_ETAPA_6_DUTY;
            break;
        
        case PID_ETAPA_6_DUTY:
            // Saturaci�n final
            if(PID.Acumulado >  24.0f) PID.Acumulado =  24.0f;
            if(PID.Acumulado < -24.0f) PID.Acumulado = -24.0f;

            SalidaPID = (int16_t)PID.Acumulado * 25;

            // Terminar el ciclo
            PID.etapa = PID_ETAPA_7_Rx1;
            break;
            
        case PID_ETAPA_7_Rx1:
            // enviar SetPoint
            UART1_SendNumber(SetPoint);
            PID.etapa = PID_ETAPA_8_Rx2;
            break;
            
        case PID_ETAPA_8_Rx2:
            // enviar SetPoint
            UART1_SendNumber(PosActual);
            PID.etapa = PID_ETAPA_9_Rx3;
            break;  
            
        case PID_ETAPA_9_Rx3:
            // enviar SetPoint
            UART1_SendNumber(Error);
            PID.etapa = PID_ETAPA_10_Rx4;
            break; 
            
        case PID_ETAPA_10_Rx4:
            // enviar SetPoint
            UART1_SendNumber(SalidaPID);
            PID.etapa = PID_ETAPA_0_LECTURA;
            PID.habilitado = false;
            break;     
    }
}