/**
 * UART1 Driver File for PIC18F46K42
 * 
 * @Company
 *   Microchip Technology Inc.
 * 
 * @File Name
 *   uart1.c
 * 
 * @Summary
 *   UART1 driver with buffered RX/TX, interrupt support, and helper functions.
 * 
 * @Description
 *   Combina la base generada por MCC Melody para PIC18 con funciones pr�cticas
 *   como env�o de n�meros, cadenas y manejo b�sico de errores UART.
 * 
 *   Compatible con XC8 v3.10
 */

#include "../uart1.h"
#include "../../timer/tmr0.h"
#include <stdio.h>
#include <string.h>
#include <stdbool.h>

/**
 * Section: Buffer Configuration
 */
#define UART1_TX_BUFFER_SIZE   64U
#define UART1_RX_BUFFER_SIZE   64U
#define UART1_TX_BUFFER_MASK   (UART1_TX_BUFFER_SIZE - 1U)
#define UART1_RX_BUFFER_MASK   (UART1_RX_BUFFER_SIZE - 1U)

/**
 * Section: Global Variables
 */
static volatile uint8_t uart1TxHead = 0;
static volatile uint8_t uart1TxTail = 0;
static volatile uint8_t uart1TxBufferRemaining = UART1_TX_BUFFER_SIZE;
static volatile uint8_t uart1TxBuffer[UART1_TX_BUFFER_SIZE];

static volatile uint8_t uart1RxHead = 0;
static volatile uint8_t uart1RxTail = 0;
static volatile uint8_t uart1RxCount = 0;
static volatile uint8_t uart1RxBuffer[UART1_RX_BUFFER_SIZE];

static volatile uart1_status_t uart1RxStatusBuffer[UART1_RX_BUFFER_SIZE];
static volatile uart1_status_t uart1RxLastError;

/**
 * Section: Callback Function Pointers
 */
static void (*UART1_FramingErrorHandler)(void);
static void (*UART1_OverrunErrorHandler)(void);
static void (*UART1_ParityErrorHandler)(void);
void (*UART1_RxInterruptHandler)(void);
void (*UART1_TxInterruptHandler)(void);
static void (*UART1_TxCompleteHandler)(void);



/**
 * Section: Function Declarations (Local)
 */
static void UART1_DefaultFramingErrorCallback(void);
static void UART1_DefaultOverrunErrorCallback(void);
static void UART1_DefaultParityErrorCallback(void);

/**
 * Section: Initialization
 */
void UART1_Initialize(void)
{
    // Disable interrupts before configuration
    PIE3bits.U1RXIE = 0;
    PIE3bits.U1TXIE = 0;

    UART1_RxInterruptHandler = UART1_ReceiveISR;
    UART1_TxInterruptHandler = UART1_TransmitISR;

    // --- UART Registers Configuration ---
    U1CON0 = 0xB0;   // MODE: Async 8-bit, RXEN enabled, TXEN enabled
    U1CON1 = 0x80;   // ON enabled
    U1CON2 = 0x08;   // 1 stop bit, polarity normal
    U1BRGL = 0x40;   // Baud rate low byte
    U1BRGH = 0x03;   // Baud rate high byte (ej: 9600 con Fosc=16MHz aprox)
    U1FIFO = 0x2E;   // FIFO config (default)
    U1ERRIR = 0x80;  // Clear error flags

    UART1_FramingErrorCallbackRegister(UART1_DefaultFramingErrorCallback);
    UART1_OverrunErrorCallbackRegister(UART1_DefaultOverrunErrorCallback);
    UART1_ParityErrorCallbackRegister(UART1_DefaultParityErrorCallback);

    uart1RxLastError.status = 0;
    uart1TxHead = uart1TxTail = 0;
    uart1TxBufferRemaining = UART1_TX_BUFFER_SIZE;
    uart1RxHead = uart1RxTail = uart1RxCount = 0;

    // Enable receive interrupt
    PIE3bits.U1RXIE = 1;
}

/**
 * Section: Basic UART Control
 */
void UART1_Enable(void)       { U1CON1bits.ON = 1; }
void UART1_Disable(void)      { U1CON1bits.ON = 0; }
void UART1_TransmitEnable(void)  { U1CON0bits.TXEN = 1; }
void UART1_TransmitDisable(void) { U1CON0bits.TXEN = 0; }
void UART1_ReceiveEnable(void)   { U1CON0bits.RXEN = 1; }
void UART1_ReceiveDisable(void)  { U1CON0bits.RXEN = 0; }

/**
 * Section: Status Functions
 */
bool UART1_IsRxReady(void) { return (uart1RxCount > 0); }
bool UART1_IsTxReady(void) { return (uart1TxBufferRemaining > 0); }
bool UART1_IsTxDone(void)  { return U1ERRIRbits.TXMTIF; }

size_t UART1_ErrorGet(void)
{
    uart1RxLastError.status = uart1RxStatusBuffer[uart1RxTail].status;
    return uart1RxLastError.status;
}

/**
 * Section: Read & Write
 */
uint8_t UART1_Read(void)
{
    uint8_t readValue;

    while (uart1RxCount == 0); // espera hasta que haya dato

    readValue = uart1RxBuffer[uart1RxTail];
    uart1RxTail = (uart1RxTail + 1U) & UART1_RX_BUFFER_MASK;

    PIE3bits.U1RXIE = 0;
    uart1RxCount--;
    PIE3bits.U1RXIE = 1;

    return readValue;
}

void UART1_Write(uint8_t txData)
{
    while (!UART1_IsTxReady()); // espera espacio

    uint8_t tempHead = (uart1TxHead + 1U) & UART1_TX_BUFFER_MASK;

    uart1TxBuffer[uart1TxHead] = txData;
    uart1TxHead = tempHead;
    PIE3bits.U1TXIE = 1;
    uart1TxBufferRemaining--;
}

/**
 * Section: Interrupt Service Routines
 */
void UART1_ReceiveISR(void)
{
    uart1RxStatusBuffer[uart1RxHead].status = 0;

    if (U1ERRIRbits.FERIF) {
        uart1RxStatusBuffer[uart1RxHead].ferr = 1;
        UART1_FramingErrorHandler();
    }

    if (U1ERRIRbits.RXFOIF) {
        uart1RxStatusBuffer[uart1RxHead].oerr = 1;
        UART1_OverrunErrorHandler();
    }

    uart1RxBuffer[uart1RxHead] = U1RXB;
    uart1RxHead = (uart1RxHead + 1U) & UART1_RX_BUFFER_MASK;
    uart1RxCount++;

    if (UART1_RxInterruptHandler != NULL)
        UART1_RxInterruptHandler();
}

void UART1_TransmitISR(void)
{
    if (uart1TxBufferRemaining < UART1_TX_BUFFER_SIZE) {
        U1TXB = uart1TxBuffer[uart1TxTail];
        uart1TxTail = (uart1TxTail + 1U) & UART1_TX_BUFFER_MASK;
        uart1TxBufferRemaining++;
    } else {
        PIE3bits.U1TXIE = 0;
    }

    if (UART1_TxCompleteHandler != NULL)
        UART1_TxCompleteHandler();
}

/**
 * Section: Error Callback Defaults
 */
static void UART1_DefaultFramingErrorCallback(void) {}
static void UART1_DefaultOverrunErrorCallback(void)
{
    // Reset CREN to recover from overrun
    U1CON0bits.RXEN = 0;
    U1CON0bits.RXEN = 1;
}
static void UART1_DefaultParityErrorCallback(void) {}

/**
 * Section: Callback Registration
 */
void UART1_FramingErrorCallbackRegister(void (*callback)(void))
{
    if (callback != NULL) UART1_FramingErrorHandler = callback;
}
void UART1_OverrunErrorCallbackRegister(void (*callback)(void))
{
    if (callback != NULL) UART1_OverrunErrorHandler = callback;
}
void UART1_ParityErrorCallbackRegister(void (*callback)(void))
{
    if (callback != NULL) UART1_ParityErrorHandler = callback;
}
void UART1_RxCallbackRegister(void (*callback)(void))
{
    if (callback != NULL) UART1_RxInterruptHandler = callback;
}
void UART1_TxCallbackRegister(void (*callback)(void))
{
    if (callback != NULL) UART1_TxInterruptHandler = callback;
}
void UART1_TxCompleteCallbackRegister(void (*callback)(void))
{
    if (callback != NULL) UART1_TxCompleteHandler = callback;
}

/**
 * Section: Helper Functions (como en el PIC16)
 */

// Enviar n�mero entero con salto de l�nea
void UART1_SendNumber(int16_t number)
{
    uint8_t highByte = (number >> 8) & 0xFF;
    uint8_t lowByte  = number & 0xFF;

    UART1_Write(lowByte);   // Luego el byte bajo
    UART1_Write(highByte);  // Primero el byte alto    
}


void UART1_SetRxInterruptHandler(void (*InterruptHandler)(void))
{
    UART1_RxInterruptHandler = InterruptHandler;
}


// =================== CALLBACK DE UART ===================
void UART1_CustomHandler(void)
{
    uint8_t dato = U1RXB; // leer directamente el byte recibido
    uartRxBuffer[uartRxHead][uartCharPos++] = dato;

    if (dato == '\n' || uartCharPos >= UART_MSG_LEN - 1) {
        uartRxBuffer[uartRxHead][uartCharPos] = '\0';
        uartCharPos = 0;
        uartRxHead = (uartRxHead + 1) % UART_RX_BUFFER_SIZE;
        rxDataReady = true;
    }
}


/**
 * End of File
 */

