/**
 * TMR0 Generated Driver File for PIC18F46K42
 * 
 * @file tmr0.c
 * 
 * @brief Driver implementation for TMR0 using XC8 v3.10
 *
 * @device PIC18F46K42
*/

#include <xc.h>
#include "../../uart/uart1.h"
#include "../tmr0.h"

static void (*TMR0_PeriodMatchCallback)(void);
static void TMR0_DefaultCallback(void);

extern PID_Data_t PID;
/**
  Section: TMR0 APIs
*/ 

void TMR0_Initialize(void)
{
    TMR0H = 0xF7;                    // Period 8ms; Frequency 31000 Hz; Count 247
    TMR0L = 0x0;

    T0CON1 = (4 << _T0CON1_T0CS_POSN)   // T0CS LFINTOSC
        | (0 << _T0CON1_T0CKPS_POSN)   // T0CKPS 1:1
        | (1 << _T0CON1_T0ASYNC_POSN);  // T0ASYNC not_synchronised

    TMR0_PeriodMatchCallback = TMR0_DefaultCallback;

    PIR3bits.TMR0IF = 0;	   
    PIE3bits.TMR0IE = 1;	

    T0CON0 = (0 << _T0CON0_T0OUTPS_POSN)   // T0OUTPS 1:1
        | (1 << _T0CON0_T0EN_POSN)   // T0EN enabled
        | (0 << _T0CON0_T0MD16_POSN);  // T0MD16 8-bit
}

void TMR0_Deinitialize(void)
{
    T0CON0bits.T0EN = 0;
    PIE3bits.TMR0IE = 0;
    
    T0CON0 = 0x0;
    T0CON1 = 0x0;
    TMR0H = 0xFF;
    TMR0L =0x0;
}

void TMR0_Start(void)
{
    T0CON0bits.T0EN = 1;
}

void TMR0_Stop(void)
{
    T0CON0bits.T0EN = 0;
}

uint8_t TMR0_CounterGet(void)
{
    return TMR0L;
}

void TMR0_CounterSet(uint8_t counterValue)
{
    TMR0L = counterValue;
}

void TMR0_PeriodSet(uint8_t periodValue)
{
    TMR0H = periodValue;
}

uint8_t TMR0_PeriodGet(void)
{
    return TMR0H;
}

void TMR0_TMRInterruptEnable(void)
{
    PIE3bits.TMR0IE = 1;
}

void TMR0_TMRInterruptDisable(void)
{
    PIE3bits.TMR0IE = 0;
}

void TMR0_ISR(void)
{
    PIR3bits.TMR0IF = 0; // Limpia el flag

    if (TMR0_PeriodMatchCallback != NULL)
    {
        TMR0_PeriodMatchCallback();
    }
}

void TMR0_PeriodMatchCallbackRegister(void (*callbackHandler)(void))
{
    TMR0_PeriodMatchCallback = callbackHandler;
}

static void TMR0_DefaultCallback(void)
{
    // Callback por defecto (vac�o)
}

// =================== CALLBACK DEL TIMER0 ===================
void TMR0_UserInterrupt(void)
{
    PID.habilitado = true;
}

/**
 * Ejemplo de callback personalizado:
 * Env�a '1' por UART cada vez que el TMR0 desborda (~8 ms)
 */