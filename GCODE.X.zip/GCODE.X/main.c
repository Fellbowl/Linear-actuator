#include "mcc_generated_files/system/system.h"
#include "mcc_generated_files/system/config_bits.h"
#include "mcc_generated_files/system/pins.h"
#include "mcc_generated_files/uart/eusart1.h"
#include "mcc_generated_files/system/interrupt.h"
#include "mcc_generated_files/system/clock.h"

#include <xc.h>
#include <stdint.h>
#include <stdbool.h>
#include <string.h>   
#include <stdlib.h>  

// =================== ESTRUCTURAS ===================
typedef enum {
    STATE_IDLE,
    STATE_TX_SEND,
    STATE_RX_PROCESS
} State;

typedef struct {
    char code[4];
    uint8_t id;
} GCodeEntry;

typedef struct {
    uint16_t posX;
    uint16_t velY;
    bool valid;
} G00_Command;

// =================== TABLA GCODE ===================
const GCodeEntry gcodeTable[] = {
    {"G00", 0}, // G00 Xnnnn Ynnnn
    {"M03", 1}, // Encender motor
    {"M05", 2}, // Apagar motor
    {"G28", 3}  // Home
};
#define NUM_GCODES (sizeof(gcodeTable)/sizeof(GCodeEntry))

// =================== FUNCIONES DECODE ===================
int decodeGcode(char *input) {
    for (uint8_t i = 0; i < NUM_GCODES; i++) {
        if (strncmp(input, gcodeTable[i].code, 3) == 0) {
            return gcodeTable[i].id;
        }
    }
    return -1;
}

G00_Command parseG00(char *input) {
    G00_Command cmd = {0, 0, false};

    char *xPtr = strchr(input, 'X');
    char *yPtr = strchr(input, 'Y');

    if (xPtr && yPtr) {
        int xVal = atoi(xPtr + 1);
        int yVal = atoi(yPtr + 1);

        if (xVal >= 0 && xVal <= 2000 && yVal >= 0 && yVal <= 24000) {
            cmd.posX = (uint16_t)xVal;
            cmd.velY = (uint16_t)yVal;
            cmd.valid = true;
        }
    }
    return cmd;
}

// =================== MAIN ===================
void main(void) {
    SYSTEM_Initialize();

    INTCONbits.GIE = 1;
    INTCONbits.PEIE = 1;
    PIE3bits.RC1IE = 1;   // RX interrupt

    State state = STATE_IDLE;
    uint8_t counter = 0;

    while (1) {
        switch (state) {
            case STATE_IDLE:
                if (txFlag) {
                    state = STATE_TX_SEND;
                } else if (rxIndex > 0) {
                    state = STATE_RX_PROCESS;
                }
                break;

            case STATE_TX_SEND:
                EUSART1_Write(counter++);  // enviar binario cada 100 ms
                txFlag = false;
                state = STATE_IDLE;
                break;

            case STATE_RX_PROCESS: {
                // Convertir lo recibido en string
                rxBuffer[rxIndex] = '\0';  // asegurar fin de cadena
                int id = decodeGcode((char*)rxBuffer);

                if (id == 0) { // G00
                    G00_Command cmd = parseG00((char*)rxBuffer);
                    if (cmd.valid) {
                        // Aqu� usar los par�metros X e Y
                        // Ejemplo: mover motor
                    } else {
                        // Comando G00 inv�lido
                    }
                }
                else if (id == 1) {
                    // M03 ? Encender motor
                }
                else if (id == 2) {
                    // M05 ? Apagar motor
                }
                else if (id == 3) {
                    // G28 ? Home m�quina
                }
                else {
                    // Comando desconocido
                }

                rxIndex = 0;  // limpiar buffer
                state = STATE_IDLE;
                break;
            }

            default:
                state = STATE_IDLE;
                break;
        }
    }
}
