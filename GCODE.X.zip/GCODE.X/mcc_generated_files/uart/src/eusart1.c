#include "../eusart1.h"

const uart_drv_interface_t UART1 = {
    .Initialize = &EUSART1_Initialize,
    .Deinitialize = &EUSART1_Deinitialize,
    .Read = &EUSART1_Read,
    .Write = &EUSART1_Write,
    .IsRxReady = &EUSART1_IsRxReady,
    .IsTxReady = &EUSART1_IsTxReady,
    .IsTxDone = &EUSART1_IsTxDone,
    .TransmitEnable = &EUSART1_TransmitEnable,
    .TransmitDisable = &EUSART1_TransmitDisable,
    .AutoBaudSet = &EUSART1_AutoBaudSet,
    .AutoBaudQuery = &EUSART1_AutoBaudQuery,
    .BRGCountSet = NULL,
    .BRGCountGet = NULL,
    .BaudRateSet = NULL,
    .BaudRateGet = NULL,
    .AutoBaudEventEnableGet = NULL,
    .ErrorGet = &EUSART1_ErrorGet,
    .TxCompleteCallbackRegister = NULL,
    .RxCompleteCallbackRegister = NULL,
    .TxCollisionCallbackRegister = NULL,
    .FramingErrorCallbackRegister = NULL,   
    .OverrunErrorCallbackRegister = NULL,   
    .ParityErrorCallbackRegister = NULL,
    .EventCallbackRegister = NULL,
};


// ========================
// Variables internas
// ========================
static volatile eusart1_status_t eusart1RxLastError;

static void (*EUSART1_FramingErrorHandler)(void) = NULL;
static void (*EUSART1_OverrunErrorHandler)(void) = NULL;

static void EUSART1_DefaultFramingErrorCallback(void);
static void EUSART1_DefaultOverrunErrorCallback(void);

// ========================
// Inicializaci�n completa
// ========================
void EUSART1_Initialize(void)
{
    // Configuraci�n de baudios: 9600bps con Fosc=4MHz, BRGH=1
    BAUD1CON = 0x08;     // BRG16 = 0 (8-bit generator), ABDEN = 0
    RC1STA   = 0x90;     // SPEN = 1 (serial port enable), CREN = 1 (continous receive enable)
    TX1STA   = 0x24;     // TXEN = 1 (transmit enable), BRGH = 1 (high speed)
    
    SP1BRGL  = 25;       // 9600 baud @ 4MHz
    SP1BRGH  = 0;

    eusart1RxLastError.status = 0;  
}

void EUSART1_Deinitialize(void)
{
    BAUD1CON = 0x00;
    RC1STA   = 0x00;
    TX1STA   = 0x00;
    SP1BRGL  = 0x00;
    SP1BRGH  = 0x00;
}

void EUSART1_Enable(void)              { RC1STAbits.SPEN = 1; }
void EUSART1_Disable(void)             { RC1STAbits.SPEN = 0; }
void EUSART1_TransmitEnable(void)      { TX1STAbits.TXEN = 1; }
void EUSART1_TransmitDisable(void)     { TX1STAbits.TXEN = 0; }
void EUSART1_ReceiveEnable(void)       { RC1STAbits.CREN = 1; }
void EUSART1_ReceiveDisable(void)      { RC1STAbits.CREN = 0; }
void EUSART1_SendBreakControlEnable(void)  { TX1STAbits.SENDB = 1; }
void EUSART1_SendBreakControlDisable(void) { TX1STAbits.SENDB = 0; }

void EUSART1_AutoBaudSet(bool enable) { BAUD1CONbits.ABDEN = enable; }
bool EUSART1_AutoBaudQuery(void)      { return (bool)(!BAUD1CONbits.ABDEN); }
bool EUSART1_IsAutoBaudDetectOverflow(void) { return (bool)BAUD1CONbits.ABDOVF; }
void EUSART1_AutoBaudDetectOverflowReset(void) { BAUD1CONbits.ABDOVF = 0; }

bool EUSART1_IsRxReady(void) { return PIR3bits.RC1IF; }
bool EUSART1_IsTxReady(void) { return (PIR3bits.TX1IF && TX1STAbits.TXEN); }
bool EUSART1_IsTxDone(void)  { return TX1STAbits.TRMT; }

size_t EUSART1_ErrorGet(void) { return eusart1RxLastError.status; }

uint8_t EUSART1_Read(void)
{
    eusart1RxLastError.status = 0;

    if(RC1STAbits.OERR) {
        eusart1RxLastError.oerr = 1;
        if(EUSART1_OverrunErrorHandler) EUSART1_OverrunErrorHandler();
    }
    if(RC1STAbits.FERR) {
        eusart1RxLastError.ferr = 1;
        if(EUSART1_FramingErrorHandler) EUSART1_FramingErrorHandler();
    }

    return RC1REG;
}

void EUSART1_Write(uint8_t txData)
{
    while(!EUSART1_IsTxReady()); // espera a que TX est� listo
    TX1REG = txData;
}