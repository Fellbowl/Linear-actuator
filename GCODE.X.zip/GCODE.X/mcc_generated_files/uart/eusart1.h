#ifndef EUSART1_H
#define EUSART1_H

#include <stdbool.h>
#include <stdint.h>
#include "../system/system.h"
#include "uart_drv_interface.h"

#define UART1_interface UART1

#define UART1_Initialize     EUSART1_Initialize
#define UART1_Deinitialize   EUSART1_Deinitialize
#define UART1_Write          EUSART1_Write
#define UART1_Read           EUSART1_Read
#define UART1_IsRxReady      EUSART1_IsRxReady
#define UART1_IsTxReady      EUSART1_IsTxReady
#define UART1_IsTxDone       EUSART1_IsTxDone

#define UART1_TransmitEnable       EUSART1_TransmitEnable
#define UART1_TransmitDisable      EUSART1_TransmitDisable
#define UART1_AutoBaudSet          EUSART1_AutoBaudSet
#define UART1_AutoBaudQuery        EUSART1_AutoBaudQuery
#define UART1_BRGCountSet                (NULL)
#define UART1_BRGCountGet                (NULL)
#define UART1_BaudRateSet                (NULL)
#define UART1_BaudRateGet                (NULL)
#define UART1_AutoBaudEventEnableGet     (NULL)
#define UART1_ErrorGet                   EUSART1_ErrorGet

#define UART1_TxCompleteCallbackRegister     (NULL)
#define UART1_RxCompleteCallbackRegister     (NULL)
#define UART1_TxCollisionCallbackRegister    (NULL)
#define UART1_FramingErrorCallbackRegister   EUSART1_FramingErrorCallbackRegister
#define UART1_OverrunErrorCallbackRegister   EUSART1_OverrunErrorCallbackRegister
#define UART1_ParityErrorCallbackRegister    (NULL)
#define UART1_EventCallbackRegister          (NULL)

typedef union {
    struct {
        uint8_t perr : 1;     /**< Parity Error */
        uint8_t ferr : 1;     /**< Framing Error */
        uint8_t oerr : 1;     /**< Overrun Error */
        uint8_t reserved : 5;
    };
    size_t status;
} eusart1_status_t;

extern const uart_drv_interface_t UART1;

// ==== Drivers de bajo nivel (EUSART1) ====
void EUSART1_Initialize(void);
void EUSART1_Deinitialize(void);
void EUSART1_Enable(void);
void EUSART1_Disable(void);
void EUSART1_TransmitEnable(void);
void EUSART1_TransmitDisable(void);
void EUSART1_ReceiveEnable(void);
void EUSART1_ReceiveDisable(void);
void EUSART1_SendBreakControlEnable(void);
void EUSART1_SendBreakControlDisable(void);
void EUSART1_AutoBaudSet(bool enable);
bool EUSART1_AutoBaudQuery(void);
bool EUSART1_IsAutoBaudDetectOverflow(void);
void EUSART1_AutoBaudDetectOverflowReset(void);
bool EUSART1_IsRxReady(void);
bool EUSART1_IsTxReady(void);
bool EUSART1_IsTxDone(void);
size_t EUSART1_ErrorGet(void);
uint8_t EUSART1_Read(void);
void EUSART1_Write(uint8_t txData);

// ==== Buffers de comunicaci�n ====
#define BUFFER_SIZE 64
volatile uint8_t rxBuffer[BUFFER_SIZE];
volatile uint8_t rxIndex;
volatile bool txFlag;

#endif // EUSART1_H
