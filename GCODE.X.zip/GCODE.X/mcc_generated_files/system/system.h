#ifndef SYSTEM_H
#define	SYSTEM_H

#include <xc.h>
#include <stdint.h>
#include <stdbool.h>
#include "config_bits.h"
#include "../system/pins.h"
#include "../uart/eusart1.h"
#include "../system/interrupt.h"
#include "../system/clock.h"

void SYSTEM_Initialize(void);

#endif // SYSTEM_H