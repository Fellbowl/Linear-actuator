#include "../system.h"
#include "../config_bits.h"
#include "../pins.h"
#include "../../uart/eusart1.h"
#include "../interrupt.h"
#include "../clock.h"

void (*INT_InterruptHandler)(void);

void  INTERRUPT_Initialize (void)
{
    // Clear the interrupt flag
    // Set the external interrupt edge detect
    EXT_INT_InterruptFlagClear();   
    EXT_INT_risingEdgeSet();
    // Set Default Interrupt Handler
    INT_SetInterruptHandler(INT_DefaultInterruptHandler);
    // EXT_INT_InterruptEnable();
}

void INT_ISR(void)
{
    EXT_INT_InterruptFlagClear();

    // Callback function gets called everytime this ISR executes
    INT_CallBack();    
}

void INT_CallBack(void)
{
    // Add your custom callback code here
    if(INT_InterruptHandler)
    {
        INT_InterruptHandler();
    }
}

void INT_SetInterruptHandler(void (* InterruptHandler)(void)){
    INT_InterruptHandler = InterruptHandler;
}

void INT_DefaultInterruptHandler(void){
    // add your INT interrupt custom code
    // or set custom function using INT_SetInterruptHandler()
}

void __interrupt() ISR(void) {
    // RX interrupt (EUSART1)
    if (PIR3bits.RC1IF) {
        rxBuffer[rxIndex++] = RCREG;  
        if(rxIndex >= BUFFER_SIZE) rxIndex = 0;
        PIR3bits.RC1IF = 0;   // limpiar bandera
    }

    // Timer0 interrupt
    if (PIR0bits.TMR0IF) {
        txFlag = true;        // Se�al de que toca enviar
        TMR0 = 6;             // recargar para 100ms aprox
        PIR0bits.TMR0IF = 0;  // limpiar bandera
    }
}