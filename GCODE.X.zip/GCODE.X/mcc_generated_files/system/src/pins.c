#include "../system.h"
#include "../config_bits.h"
#include "../pins.h"
#include "../../uart/eusart1.h"
#include "../interrupt.h"
#include "../clock.h"


void PIN_MANAGER_Initialize(void)
{
   /**
    LATx registers
    */
    LATA = 0x0;
    LATC = 0x0;

    /**
    TRISx registers
    */
    TRISA = 0x3F;
    TRISC = 0x3F;

    /**
    ANSELx registers
    */
    ANSELA = 0x37;
    ANSELC = 0x1F;

    /**
    WPUx registers
    */
    WPUA = 0x0;
    WPUC = 0x0;
  
    /**
    ODx registers
    */
   
    ODCONA = 0x0;
    ODCONC = 0x0;
    /**
    SLRCONx registers
    */
    SLRCONA = 0x37;
    SLRCONC = 0x3F;
    /**
    INLVLx registers
    */
    INLVLA = 0x3F;
    INLVLC = 0x3F;

    /**
    PPS registers
    */
    RX1PPS = 0x15; //RC5->EUSART1:RX1;

    /**
    APFCON registers
    */

   /**
    IOCx registers 
    */
    IOCAP = 0x0;
    IOCAN = 0x0;
    IOCAF = 0x0;
    IOCCP = 0x0;
    IOCCN = 0x0;
    IOCCF = 0x0;


}
  
void PIN_MANAGER_IOC(void)
{
}