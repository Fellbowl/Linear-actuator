#include "../system.h"
#include "../config_bits.h"
#include "../pins.h"
#include "../../uart/eusart1.h"
#include "../interrupt.h"
#include "../clock.h"


void SYSTEM_Initialize(void)
{
    CLOCK_Initialize();
    PIN_MANAGER_Initialize();
    EUSART1_Initialize();
    INTERRUPT_Initialize();
}

