#include "../system.h"
#include "../config_bits.h"
#include "../pins.h"
#include "../../uart/eusart1.h"
#include "../interrupt.h"
#include "../clock.h"
#include <xc.h>

volatile bool txFlag = false;

void CLOCK_Initialize(void) {
    // Timer0: Prescaler 1:256, modo 8 bits, Fosc/4 = 1 MHz @ 4 MHz
    // Per�odo = 100 ms aproximadamente
    T0CON0 = 0x90;   // T0EN=1, 8-bit
    T0CON1 = 0x46;   // Fosc/4, prescaler 1:64

    // Valor inicial (para ~100ms a 4MHz con prescaler 1:64)
    TMR0H = 100;     // Ajusta seg�n c�lculo
    TMR0L = 0;

    PIR0bits.TMR0IF = 0;   // Limpia bandera
    PIE0bits.TMR0IE = 1;   // Habilita interrupci�n
}

bool CLOCK_TxFlagGet(void) {
    return txFlag;
}

void CLOCK_TxFlagClear(void) {
    txFlag = false;
}