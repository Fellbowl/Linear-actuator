#ifndef CONFIG_BITS_H
#define	CONFIG_BITS_H

#include "../system/clock.h"

#endif