#ifndef CLOCK_H
#define	CLOCK_H

#ifndef _XTAL_FREQ
    #define _XTAL_FREQ 4000000UL   // Frecuencia de oscilador en Hz
#endif

#include <stdbool.h>
#include <stdint.h>

// Bandera de transmisi�n cada 100ms (se modifica en clock.c / ISR)
extern volatile bool txFlag;

// Inicializaci�n de Timer0
void CLOCK_Initialize(void);

// Permite leer la bandera de transmisi�n
bool CLOCK_TxFlagGet(void);

// Limpia la bandera de transmisi�n
void CLOCK_TxFlagClear(void);

#endif	/* CLOCK_H */