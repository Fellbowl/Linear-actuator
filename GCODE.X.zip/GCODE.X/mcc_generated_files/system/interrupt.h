#ifndef INTERRUPT_H
#define INTERRUPT_H

#define INTERRUPT_GlobalInterruptEnable() (INTCONbits.GIE = 1)
#define INTERRUPT_GlobalInterruptDisable() (INTCONbits.GIE = 0)
#define INTERRUPT_GlobalInterruptStatus() (INTCONbits.GIE)
#define INTERRUPT_PeripheralInterruptEnable() (INTCONbits.PEIE = 1)
#define INTERRUPT_PeripheralInterruptDisable() (INTCONbits.PEIE = 0)
#define EXT_INT_InterruptFlagClear()       (PIR0bits.INTF = 0)
#define EXT_INT_InterruptDisable()     (PIE0bits.INTE = 0)
#define EXT_INT_InterruptEnable()       (PIE0bits.INTE = 1)
#define EXT_INT_risingEdgeSet()          (INTCONbits.INTEDG = 1)
#define EXT_INT_fallingEdgeSet()          (INTCONbits.INTEDG = 0)

#include <stdbool.h>

void INTERRUPT_Initialize (void);

void INT_ISR(void);

void INT_CallBack(void);

void INT_SetInterruptHandler(void (* InterruptHandler)(void));

extern void (*INT_InterruptHandler)(void);

void INT_DefaultInterruptHandler(void);

void __interrupt() ISR(void);

#endif   // INTERRUPT_H