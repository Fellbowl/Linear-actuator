#include "mcc_generated_files/mcc.h"

#include <xc.h>
#include <stdint.h>
#include <stdbool.h>
#include <string.h>
#include <stdlib.h>


// =================== ESTRUCTURAS ===================
typedef enum {
    STATE_IDLE,
    STATE_TX_SEND,
    STATE_RX_PROCESS
} State;

typedef struct {
    char code[4];
    uint8_t id;
} GCodeEntry;

typedef struct {
    uint16_t posX;
    uint16_t velY;
    bool valid;
} G00_Command;

// =================== TABLA GCODE ===================
const GCodeEntry gcodeTable[] = {
    {"G00", 0}, // G00 Xnnnn Ynnnn
    {"M03", 1}, // Encender motor
    {"M05", 2}, // Apagar motor
    {"G28", 3}  // Home
};
#define NUM_GCODES (sizeof(gcodeTable)/sizeof(GCodeEntry))

// =================== VARIABLES ===================
#define UART_RX_BUFFER_SIZE 64   // m�ximo de mensajes pendientes
#define UART_MSG_LEN 16          // m�ximo de caracteres por mensaje

volatile char uartRxBuffer[UART_RX_BUFFER_SIZE][UART_MSG_LEN];
volatile uint8_t uartRxHead = 0; // �ndice del mensaje actual en construcci�n
volatile uint8_t uartRxTail = 0; // �ndice del mensaje a procesar
volatile uint8_t uartCharPos = 0; // posici�n dentro del mensaje actual
volatile bool rxDataReady = false;
volatile bool txFlag = false;

// =================== INTERRUPCIONES ===================
void __interrupt() ISR(void) {
    if (PIR3bits.RC1IF) {
        uint8_t dato = RC1REG; // leer SIEMPRE primero
        PIR3bits.RC1IF = 0;    // <---- LIMPIAR EL FLAG SIEMPRE
        if (RC1STAbits.OERR) { // error de overrun
            RC1STAbits.CREN = 0;
            RC1STAbits.CREN = 1;
        }

        // Guardar solo si hay espacio en buffer de mensajes
        uint8_t nextHead = (uartRxHead + 1) % UART_RX_BUFFER_SIZE;
        if (nextHead != uartRxTail) {
            uartRxBuffer[uartRxHead][uartCharPos++] = dato;

            // Si recibimos fin de l�nea, terminamos el mensaje
            if (dato == '\n' || uartCharPos >= UART_MSG_LEN - 1) {
                uartRxBuffer[uartRxHead][uartCharPos] = '\0';
                uartCharPos = 0;
                uartRxHead = nextHead;
                rxDataReady = true;
            }
        }
        // Si buffer de mensajes lleno, se pierde el dato
    }
}


void enviarNumero(int numero) {
    char buffer[6];
    sprintf(buffer, "%d\n", numero);
    for(int i = 0; buffer[i] != '\0'; i++) {
        EUSART1_Write(buffer[i]);
    }
}

// =================== FUNCIONES ===================
int decodeGcode(char *input) {
    // Quitar espacios iniciales
    while (*input == ' ' || *input == '\r' || *input == '\n') input++;

    // Buscar coincidencia exacta de 3 caracteres
    for (uint8_t i = 0; i < NUM_GCODES; i++) {
        if (strncmp(input, gcodeTable[i].code, 3) == 0) {
            return gcodeTable[i].id;
        }
    }
    return -1;
}

G00_Command parseG00(char *input) {
    G00_Command cmd = {0, 0, false};

    char *xPtr = strchr(input, 'X');
    char *yPtr = strchr(input, 'Y');

    if (xPtr && yPtr) {
        int xVal = atoi(xPtr + 1);
        int yVal = atoi(yPtr + 1);

        if (xVal >= 0 && xVal <= 2000 && yVal >= 0 && yVal <= 24000) {
            cmd.posX = (uint16_t)xVal;
            cmd.velY = (uint16_t)yVal;
            cmd.valid = true;
        }
    }
    return cmd;
}

// =================== MAIN ===================
void main(void) {
    SYSTEM_Initialize(); // MCC generated init

    TMR0_StartTimer();

    INTCONbits.GIE = 1;
    INTCONbits.PEIE = 1;
    PIE3bits.RC1IE = 1;   // habilitar RX interrupt

    G00_Command cmd;
    
    State state = STATE_IDLE;

    while (1) {

        switch(state) {
            case STATE_IDLE:
                // Si hay datos en buffer, procesar
                if (uartRxTail != uartRxHead) {
                    state = STATE_RX_PROCESS;
                }
                break;

            case STATE_RX_PROCESS: {
                // Copiar mensaje recibido a un buffer normal (no volatile)
                char receivedCopy[UART_MSG_LEN];
                strcpy(receivedCopy, (char*)uartRxBuffer[uartRxTail]);

                // Eliminar \r\n al final
                for (int i = 0; i < UART_MSG_LEN; i++) {
                    if (receivedCopy[i] == '\r' || receivedCopy[i] == '\n') {
                        receivedCopy[i] = '\0';
                        break;
                    }
                }

                int id = decodeGcode(receivedCopy);

                switch(id) {
                    case 0: { // G00
                        cmd = parseG00(receivedCopy);
                        if (cmd.valid) {
                            //StartTask(GoTo, cmd.posX, cmd.velY);
                            //LATCbits.LATC1 = 1;
                        }
                    }
                    break;
                    case 1:
                        //LATCbits.LATC2 = 1;
                        break; // M03
                    case 2:
                        //LATCbits.LATC2 = 0;
                        break; // M05
                    case 3:
                        //StartTask(GoHome, 0, 5000);
                        //LATCbits.LATC1 = 0;
                        break; // G28
                    default:
                        //LATCbits.LATC0 = 1;
                        cmd.valid = false;
                        break; // No reconocido
                }

            uartRxTail = (uartRxTail + 1) % UART_RX_BUFFER_SIZE;
            state = STATE_IDLE;
            break;
            }
        }
    }        
}