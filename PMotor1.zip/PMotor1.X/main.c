/**
  Generated Main Source File

  Company:
    Microchip Technology Inc.

  File Name:
    main.c

  Summary:
    This is the main file generated using PIC10 / PIC12 / PIC16 / PIC18 MCUs

  Description:
    This header file provides implementations for driver APIs for all modules selected in the GUI.
    Generation Information :
        Product Revision  :  PIC10 / PIC12 / PIC16 / PIC18 MCUs - 1.81.8
        Device            :  PIC16F18426
        Driver Version    :  2.00
*/

/*
    (c) 2018 Microchip Technology Inc. and its subsidiaries. 
    
    Subject to your compliance with these terms, you may use Microchip software and any 
    derivatives exclusively with Microchip products. It is your responsibility to comply with third party 
    license terms applicable to your use of third party software (including open source software) that 
    may accompany Microchip software.
    
    THIS SOFTWARE IS SUPPLIED BY MICROCHIP "AS IS". NO WARRANTIES, WHETHER 
    EXPRESS, IMPLIED OR STATUTORY, APPLY TO THIS SOFTWARE, INCLUDING ANY 
    IMPLIED WARRANTIES OF NON-INFRINGEMENT, MERCHANTABILITY, AND FITNESS 
    FOR A PARTICULAR PURPOSE.
    
    IN NO EVENT WILL MICROCHIP BE LIABLE FOR ANY INDIRECT, SPECIAL, PUNITIVE, 
    INCIDENTAL OR CONSEQUENTIAL LOSS, DAMAGE, COST OR EXPENSE OF ANY KIND 
    WHATSOEVER RELATED TO THE SOFTWARE, HOWEVER CAUSED, EVEN IF MICROCHIP 
    HAS BEEN ADVISED OF THE POSSIBILITY OR THE DAMAGES ARE FORESEEABLE. TO 
    THE FULLEST EXTENT ALLOWED BY LAW, MICROCHIP'S TOTAL LIABILITY ON ALL 
    CLAIMS IN ANY WAY RELATED TO THIS SOFTWARE WILL NOT EXCEED THE AMOUNT 
    OF FEES, IF ANY, THAT YOU HAVE PAID DIRECTLY TO MICROCHIP FOR THIS 
    SOFTWARE.
*/

#include "mcc_generated_files/mcc.h"
#include "mcc_generated_files/nco1.h"
#include "mcc_generated_files/pin_manager.h"
#include "mcc_generated_files/eusart1.h"
#include <stdint.h>
#include <stdbool.h>
#include <string.h>
#include <stdlib.h>

// =================== ENUMERACIONES ===================
typedef enum {
    STATE_IDLE,
    STATE_RECEIVING,
    STATE_READY,
    STATE_DECODE,
    STATE_EXECUTE,
    STATE_SEND
} SystemState;

typedef enum {
    CMD_NONE,
    CMD_G00,
    CMD_M03,
    CMD_M05,
    CMD_G28
} CommandID;

// =================== ESTRUCTURAS ===================
typedef struct {
    char buffer[16];
    uint8_t index;
    bool ready;
} UART_Message;

typedef struct {
    uint16_t posX;
    uint16_t velY;
    bool valid;
} G00_Command;

typedef struct {
    SystemState state;
    UART_Message msg;
    G00_Command g00;
    CommandID cmdID;
    bool txReady;
} SystemContext;

volatile char lastChar = 0;
void __interrupt() ISR(void);
static G00_Command parseG00(const char *input);
static CommandID decodeGcode(const char *input);
void UART1_CustomHandler(void);
void RxFSM(void);

#define UART_RX_BUFFER_SIZE 16   // m?ximo de mensajes pendientes
#define UART_MSG_LEN 64          // m?ximo de caracteres por mensaje
volatile char uartRxBuffer[UART_RX_BUFFER_SIZE][UART_MSG_LEN];
volatile uint8_t uartRxHead = 0; // ?ndice del mensaje actual en construcci?n
volatile uint8_t uartRxTail = 0; // ?ndice del mensaje a procesar
volatile uint8_t uartCharPos = 0; // posici?n dentro del mensaje actual
volatile bool rxDataReady = false;
volatile bool txFlag = false;

SystemContext systemCtx = {
    .state = STATE_IDLE,
    .msg = {"", 0, false},
    .g00 = {0, 0, false},
    .cmdID = CMD_NONE,
    .txReady = false
};

// ===================================================================
//TMR2
volatile bool PulseEnable = false;
volatile uint16_t PulseCount = 0;
volatile int16_t TrueCount = 0;

volatile uint16_t velocity = 0;

//NCO1
volatile uint16_t nco_current_freq = 0;
volatile uint16_t nco_ramp_target = 0;

//GoTo
volatile uint16_t ReqStep = 0;
//EUSART
volatile int valor_a_enviar = -1;


volatile bool Ocupado = false;


/*
                         Main application
 */
void SetVelocity(uint16_t);
bool GoHome(uint16_t );

typedef bool (*TaskFunction)(uint16_t arg);

#define MAX_TASKS 10

typedef struct {
    TaskFunction func;     // funci�n (GoTo, ReturnHome, etc.)
    uint16_t arg;          // argumento (posici�n objetivo)
    uint16_t velocity;     // velocidad deseada
    bool started;          // si ya se configur� la velocidad
} Task;

typedef struct {
    Task queue[MAX_TASKS];
    uint8_t head;
    uint8_t tail;
    bool running;
} TaskScheduler;

TaskScheduler scheduler = { .head = 0, .tail = 0, .running = false };


bool GoTo(uint16_t);
void StartTask(TaskFunction , uint16_t , uint16_t );
void RunTasks(void);

void main(void)
{
    // initialize the device
    SYSTEM_Initialize();
    EUSART1_SetRxInterruptHandler(UART1_CustomHandler);

    // When using interrupts, you need to set the Global and Peripheral Interrupt Enable bits
    // Use the following macros to:

    // Enable the Global Interrupts
    INTERRUPT_GlobalInterruptEnable();

    // Enable the Peripheral Interrupts
    INTERRUPT_PeripheralInterruptEnable();

    // Disable the Global Interrupts
    //INTERRUPT_GlobalInterruptDisable();

    // Disable the Peripheral Interrupts
    //INTERRUPT_PeripheralInterruptDisable();
    
    StartTask(GoHome, 0, 2000);
    
    // 2. Mover a posici�n 1500
    StartTask(GoTo, 1500, 2000);

    // 3. Mover a posici�n 0 (volver al inicio)
   // StartTask(GoTo, 0, 10000);
    
    while (1)
    {
        RxFSM();
        RunTasks();
        if (valor_a_enviar >= 0) {
            enviarNumeroSimple(valor_a_enviar);
            valor_a_enviar = -1;
        }
        
    }
}

void SetVelocity(uint16_t velocity)
{
    
    // Calculate desired frequency in Hz from velocity
    // frequency = velocity * N * MS / L
    //nco_ramp_target = (uint32_t)(velocity * 400U); // Activate to recieve mm/s
    nco_ramp_target = velocity;
    nco_current_freq = 1000;
    SetFrequency(nco_current_freq);
}

bool GoHome(uint16_t dummy)
{
    static bool initialized = false;

    if (!initialized) {
        // Se ejecuta una sola vez al comenzar la tarea
        if (DIR_GetValue()) DIR_SetLow(); // Reverse
        initialized = true;
    }
    if(MIN_GetValue()){
        PulseEnable = true;
        return false;
        
    } 
    else{
        PulseEnable = false;
        DIR_SetLow();
        TrueCount = 0;
        initialized = false; // para la pr�xima vez
        return true;
    }
}



bool GoTo(uint16_t pos)
{
    ReqStep = pos * 20;
    static bool initialized = false;

    if (!initialized) {
        // Se ejecuta una sola vez al comenzar la tarea
        if (ReqStep>TrueCount) DIR_SetHigh(); // Reverse
        else DIR_SetLow();
        initialized = true;
    }

    if (abs((int32_t)ReqStep - TrueCount) > 1) {
        PulseEnable = true;
        Ocupado = true;
        return false;
    } else {
        PulseEnable = false;
        Ocupado = false;
        initialized = false; //Permite reconfigurar direcci�n en el pr�ximo GoTo()
        return true;
    }
}

void StartTask(TaskFunction func, uint16_t arg, uint16_t velocity) {
    uint8_t next = (scheduler.tail + 1) % MAX_TASKS;
    if (next != scheduler.head) { // cola no llena
        scheduler.queue[scheduler.tail].func = func;
        scheduler.queue[scheduler.tail].arg = arg;
        scheduler.queue[scheduler.tail].velocity = velocity;
        scheduler.queue[scheduler.tail].started = false;
        scheduler.tail = next;
    }
}



void RunTasks(void) {
    if (scheduler.head == scheduler.tail) {
        scheduler.running = false;
        return;
    }

    scheduler.running = true;
    Task *current = &scheduler.queue[scheduler.head];

    // Si la tarea a�n no arranc�, configurar la velocidad
    if (!current->started) {
        SetVelocity(current->velocity);
        current->started = true;
    }

    if (current->func(current->arg) && !PulseEnable) {
        scheduler.head = (scheduler.head + 1) % MAX_TASKS;
    }
}

void UART1_CustomHandler(void)
{
    uint8_t dato = RC1REG;

    if (RC1STAbits.OERR) {
        RC1STAbits.CREN = 0;
        RC1STAbits.CREN = 1;
    }

    uint8_t nextHead = (uartRxHead + 1) % UART_RX_BUFFER_SIZE;

    if (nextHead != uartRxTail) { // espacio disponible
        uartRxBuffer[uartRxHead][uartCharPos++] = dato;

        // Fin de mensaje
        if (dato == '\n' || uartCharPos >= UART_MSG_LEN - 1) {
            uartRxBuffer[uartRxHead][uartCharPos] = '\0';
            uartCharPos = 0;
            uartRxHead = nextHead;
            rxDataReady = true; // indica que hay mensajes pendientes
        }
    }
    // si buffer lleno, se pierde el dato
}

// =================== FUNCIONES AUXILIARES ===================
static CommandID decodeGcode(const char *input) {
    if (strncmp(input, "G00", 3) == 0) return CMD_G00;
    if (strncmp(input, "M03", 3) == 0) return CMD_M03;
    if (strncmp(input, "M05", 3) == 0) return CMD_M05;
    if (strncmp(input, "G28", 3) == 0) return CMD_G28;
    return CMD_NONE;
}

static G00_Command parseG00(const char *input) {
    G00_Command cmd = {0, 0, false};
    const char *xPtr = strchr(input, 'X');
    const char *yPtr = strchr(input, 'Y');

    if (xPtr && yPtr) {
        int x = atoi(xPtr + 1);
        int y = atoi(yPtr + 1);
        if (x >= 0 && x <= 2000 && y >= 0 && y <= 24000) {
            cmd.posX = (uint16_t)x;
            cmd.velY = (uint16_t)y;
            cmd.valid = true;
        }
    }
    return cmd;
}

void RxFSM(void)
{
    // Procesar solo un mensaje pendiente (no usar while)
    if (uartRxTail == uartRxHead) return; // no hay mensajes pendientes

    char *msg = (char*)uartRxBuffer[uartRxTail];

    // Decodificar comando
    systemCtx.cmdID = decodeGcode(msg);

    switch (systemCtx.cmdID) {
        case CMD_G00:
            systemCtx.g00 = parseG00(msg);
            if (systemCtx.g00.valid) {
                // Ejecutar GoTo 1000, 20000 si quieres ejemplo fijo
                StartTask(GoTo, systemCtx.g00.posX, systemCtx.g00.velY);
            }
            break;

        case CMD_G28:
            StartTask(GoHome, 0, 5000);
            break;

        default:
            // comandos no soportados
            break;
    }

    // Avanzar cola (un mensaje procesado)
    uartRxTail = (uartRxTail + 1) % UART_RX_BUFFER_SIZE;
}